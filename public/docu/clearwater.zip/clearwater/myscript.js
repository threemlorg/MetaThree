import * as THREE from 'https://cdnjs.cloudflare.com/ajax/libs/three.js/r123/three.module.js';
import { Water } from 'http://v-slam.org/clearwater/Water2.js';
//var scene=threeml.getScene()
var mod={}
mod.name='clearwater';
mod.handle = function(ele, parent){
    var att=threeml.getAttributes(ele);
        // water
    const params = {
        color: att.color?att.color:'#ffffff',
        scale: threeml.conv.toN(att.scale, 40),
        flowX: threeml.conv.toN(att.flowx,1),
        flowY: threeml.conv.toN(att.flowy,1)
    };

    const waterGeometry = new THREE.PlaneGeometry( 20, 20 );

    var water = new Water( waterGeometry, {
        color: params.color,
        scale: params.scale,
        flowDirection: new THREE.Vector2( params.flowX, params.flowY ),
        textureWidth: 1024,
        textureHeight: 1024
    } );

    threeml.setCommonAttributes(water, att);
    if(!att.rotation){
        water.rotation.x = Math.PI * - 0.5;
    }
    parent.add( water );
    
}

threeml.registerModule(mod)